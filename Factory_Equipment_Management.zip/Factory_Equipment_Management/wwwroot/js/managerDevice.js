﻿function showDetail(idItem) {
    window.location.href = `/ManagerDevice/Detail/${idItem}`;
}

function bindPaginationEvents() {
    document.querySelectorAll('.page-btn[data-page]').forEach(function (el) {
        el.onclick = function (e) {
            e.preventDefault();
            if (this.disabled || this.classList.contains('active')) return;
            const page = this.getAttribute('data-page');
            if (page) {
                const url = new URL(window.location.href);
                url.searchParams.set('pageNumber', page);
                window.location.href = url.toString();
            }
        };
    });
}

function bindActionButtons() {
    // Toggle status
    document.querySelectorAll('.btn-toggle-status').forEach(btn => {
        btn.onclick = function () {
            if (!confirm("Bạn có chắc muốn chuyển trạng thái thiết bị này?")) return;
            const id = this.getAttribute('data-id');
            fetch(`/ManagerDevice/ToggleStatus/${id}`, { method: 'POST' })
                .then(res => {
                    if (!res.ok) throw new Error("Lỗi server");
                    return res.json();
                })
                .then(data => {
                    const statusCell = document.getElementById('status-' + id);
                    if (statusCell && data.status) {
                        statusCell.innerHTML = `<span class="status-${data.status.toLowerCase().replace(/ /g, "_")}">${data.status}</span>`;
                    } else {
                        alert("Chuyển trạng thái thất bại!");
                    }
                })
                .catch(() => alert("Không thể kết nối server hoặc lỗi server!"));
        };
    });

    // Update device (mở modal)
    document.querySelectorAll('.btn-update-device').forEach(btn => {
        btn.onclick = function () {
            const id = this.getAttribute('data-id');
            fetch(`/ManagerDevice/GetItemDetailJson?id=${id}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('update_idItem').value = data.idItem;
                    document.getElementById('update_ItemName').value = data.itemName || '';
                    document.getElementById('update_status').value = data.status || '';
                    document.getElementById('update_activedDate').value = data.activedDate ? data.activedDate.substring(0, 10) : '';
                    document.getElementById('update_maintanceDate').value = data.maintanceDate ? data.maintanceDate.substring(0, 10) : '';
                    document.getElementById('update_renewDate').value = data.renewDate ? data.renewDate.substring(0, 10) : '';
                    document.getElementById('update_model').value = data.model || '';
                    document.getElementById('update_serialNumber').value = data.serialNumber || '';
                    document.getElementById('update_supplier').value = data.supplier || '';
                    document.getElementById('update_contractor').value = data.contractor || '';
                    document.getElementById('update_idCategory').value = data.idCategory || '';

                    // Set warehouse và load area tương ứng
                    const warehouseSelect = document.getElementById('update_warehouse');
                    const areaSelect = document.getElementById('update_idArea');
                    warehouseSelect.value = data.idWarehouse || '';
                    areaSelect.innerHTML = '<option value="">-- Chọn khu vực --</option>';
                    if (data.idWarehouse) {
                        fetch(`/ManagerDevice/GetAreasByWarehouse?idWarehouse=${data.idWarehouse}`)
                            .then(res => res.json())
                            .then(areas => {
                                areas.forEach(area => {
                                    const opt = document.createElement('option');
                                    opt.value = area.idArea;
                                    opt.textContent = area.name;
                                    areaSelect.appendChild(opt);
                                });
                                areaSelect.value = data.idArea || '';
                            });
                    }

                    document.getElementById('updateDeviceModal').style.display = 'block';
                });
        };
    });

    // Delete device
    document.querySelectorAll('.btn-delete-device').forEach(btn => {
        btn.onclick = async function () {
            if (!confirm('Bạn có chắc muốn xóa thiết bị này?')) return;
            const id = this.getAttribute('data-id');
            const res = await fetch(`/ManagerDevice/DeleteDevice/${id}`, { method: 'POST' });
            if (res.ok) {
                alert('Đã xóa thành công!');
                location.reload();
            } else {
                alert('Xóa thất bại!');
            }
        };
    });

    // Nút chi tiết
    document.querySelectorAll('.btn-detail').forEach(btn => {
        btn.onclick = function () {
            const id = this.getAttribute('data-id');
            showDetail(id);
        };
    });
}

// Sự kiện cho filter form nâng cao
document.addEventListener('DOMContentLoaded', function () {
    bindPaginationEvents();
    bindActionButtons();

    // Hiện/ẩn form lọc nâng cao
    document.getElementById('showFilterForm').addEventListener('click', function () {
        document.getElementById('deviceFilterForm').style.display = 'flex';
    });
    document.getElementById('hideFilterForm').addEventListener('click', function () {
        document.getElementById('deviceFilterForm').style.display = 'none';
    });

    // Xóa bộ lọc: chỉ reset form, không reload trang
    document.getElementById('clearFilterForm').addEventListener('click', function () {
        document.getElementById('filterDeviceName').value = '';
        document.getElementById('filterLocation').value = '';
        document.getElementById('filterModel').value = '';
        document.getElementById('filterSerialNumber').value = '';
        document.getElementById('filterSupplier').value = '';
        document.getElementById('filterContractor').value = '';
        // Không reload lại trang, chỉ reset form
    });

    // Khi chọn kho, load lại khu vực tương ứng
    document.getElementById('update_warehouse').addEventListener('change', function () {
        const idWarehouse = this.value;
        const areaSelect = document.getElementById('update_idArea');
        areaSelect.innerHTML = '<option value="">-- Chọn khu vực --</option>';
        if (!idWarehouse) return;
        fetch(`/ManagerDevice/GetAreasByWarehouse?idWarehouse=${idWarehouse}`)
            .then(res => res.json())
            .then(areas => {
                areas.forEach(area => {
                    const opt = document.createElement('option');
                    opt.value = area.idArea;
                    opt.textContent = area.name;
                    areaSelect.appendChild(opt);
                });
            });
    });

    // Đóng modal
    document.getElementById('closeUpdateModal').onclick = function () {
        document.getElementById('updateDeviceModal').style.display = 'none';
    };

    // Submit form cập nhật
    document.getElementById('updateDeviceForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.delete('warehouse');
        formData.set('idArea', document.getElementById('update_idArea').value);

        fetch('/ManagerDevice/UpdateDevice', {
            method: 'POST',
            body: JSON.stringify(Object.fromEntries(formData)),
            headers: { 'Content-Type': 'application/json' }
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('Cập nhật thành công!');
                    location.reload();
                } else {
                    alert('Cập nhật thất bại!\n' + (data.message || ''));
                    console.error('Server trả về:', data);
                }
            })
            .catch(err => {
                alert('Có lỗi xảy ra khi cập nhật!');
                console.error('Lỗi khi cập nhật:', err);
            });
    });

    // Xử lý status filter buttons: xóa hết filter nâng cao khỏi URL trước khi reload
    document.querySelectorAll('.filter-btn[data-status]').forEach(btn => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.filter-btn[data-status]').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const status = this.getAttribute('data-status');
            const url = new URL(window.location.href);

            // XÓA TẤT CẢ filter nâng cao khi click status button
            url.searchParams.delete('filterDeviceName');
            url.searchParams.delete('filterLocation');
            url.searchParams.delete('filterModel');
            url.searchParams.delete('filterSerialNumber');
            url.searchParams.delete('filterSupplier');
            url.searchParams.delete('filterContractor');

            // Chỉ giữ lại status
            if (status) {
                url.searchParams.set('status', status);
            } else {
                url.searchParams.delete('status');
            }
            url.searchParams.set('pageNumber', 1);
            window.location.href = url.toString();
        });
    });
});

// Hàm lọc bảng theo trạng thái (nếu dùng filter client-side)
function filterTableByStatus(status) {
    const rows = document.querySelectorAll('.device-table tbody tr');
    rows.forEach(row => {
        const statusCell = row.querySelector('td[id^="status-"] span');
        if (!status || !statusCell || statusCell.textContent.trim() === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}