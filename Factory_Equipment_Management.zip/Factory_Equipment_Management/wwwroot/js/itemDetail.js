﻿// Image Modal Functionality
const imageModal = document.getElementById('imageModal');
const imageModalImg = document.getElementById('imageModalImg');
const imageModalClose = document.getElementById('imageModalClose');

// Function to open image modal
function openImageModal(imageSrc) {
    imageModalImg.src = imageSrc;
    imageModal.classList.add('show');
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

// Function to close image modal
function closeImageModal() {
    imageModal.classList.remove('show');
    document.body.style.overflow = ''; // Restore scrolling
}

// Add click event listeners to images
document.querySelector('.qr-img')?.addEventListener('click', function () {
    openImageModal(this.src);
});

document.querySelector('.device-img')?.addEventListener('click', function () {
    openImageModal(this.src);
});

// Close modal when clicking close button
imageModalClose?.addEventListener('click', closeImageModal);

// Close modal when clicking outside the image
imageModal?.addEventListener('click', function (e) {
    if (e.target === imageModal) {
        closeImageModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && imageModal.classList.contains('show')) {
        closeImageModal();
    }
});

document.getElementById('btnDownloadQR')?.addEventListener('click', function () {
    const qrImg = document.querySelector('.qr-img');
    if (!qrImg) return;

    // Nếu là data URL, chuyển sang Blob để tải về ổn định trên mọi trình duyệt
    if (qrImg.src.startsWith('data:image')) {
        const arr = qrImg.src.split(',');
        const mime = arr[0].match(/:(.*?);/)[1];
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        const blob = new Blob([u8arr], { type: mime });
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = 'QRCode.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } else {
        // Nếu là link ảnh thông thường
        const link = document.createElement('a');
        link.href = qrImg.src;
        link.download = 'QRCode.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Thêm hiệu ứng rung
    this.classList.add('shake');
    setTimeout(() => this.classList.remove('shake'), 400);
});

function renderMaintenanceTable(data) {
    let html = `
        <table class="item-detail-table" id="maintenance-table">
            <thead>
                <tr>
                    <th>Ngày xong</th>
                    <th>Người bảo trì</th>
                    <th>Nguyên nhân</th>
                    <th>Loại</th>
                    <th>Chi phí</th>
                </tr>
            </thead>
            <tbody>
    `;
    if (data && data.length) {
        data.forEach(m => {
            html += `
                <tr>
                    <td>${m.dateEnd ? new Date(m.dateEnd).toLocaleDateString('vi-VN') : ''}</td>
                    <td>${m.staffName ?? ''}</td>
                    <td>${m.reason ?? ''}</td>
                    <td>${m.type ?? ''}</td>
                    <td>${m.budget?.toLocaleString('vi-VN') ?? '0'} đ</td>
                </tr>
            `;
        });
    } else {
        html += `<tr><td colspan="5" style="text-align:center;">Không có dữ liệu</td></tr>`;
    }
    html += `</tbody></table>`;
    document.getElementById('history-content').innerHTML = html;
}

function renderTransferTable(data) {
    let html = `
        <table class="item-detail-table">
            <thead>
                <tr>
                    <th>Ngày bàn giao</th>
                    <th>Vị trí cũ</th>
                    <th>Vị trí mới</th>
                </tr>
            </thead>
            <tbody>
    `;
    if (data && data.length) {
        data.forEach(t => {
            html += `
                <tr>
                    <td>${t.transferDate ? new Date(t.transferDate).toLocaleDateString('vi-VN') : ''}</td>
                    <td>${t.oldLocation ?? ''}</td>
                    <td>${t.newLocation ?? ''}</td>
                </tr>
            `;
        });
    } else {
        html += `<tr><td colspan="3" style="text-align:center;">Không có dữ liệu</td></tr>`;
    }
    html += `</tbody></table>`;
    document.getElementById('history-content').innerHTML = html;
}

document.getElementById('btnShowMaintenance')?.addEventListener('click', function () {
    document.getElementById('history-title').innerText = 'Lịch sử bảo trì';
    this.classList.add('btn-active');
    document.getElementById('btnShowTransfer').classList.remove('btn-active');
    document.getElementById('maintenance-table').style.display = '';
    document.getElementById('transfer-table').style.display = 'none';
});

document.getElementById('btnShowTransfer')?.addEventListener('click', function () {
    document.getElementById('history-title').innerText = 'Lịch sử bàn giao';
    this.classList.add('btn-active');
    document.getElementById('btnShowMaintenance').classList.remove('btn-active');
    document.getElementById('maintenance-table').style.display = 'none';
    document.getElementById('transfer-table').style.display = '';
});

// Khi vào trang, tự động load bảng bảo trì (nếu muốn)
window.addEventListener('DOMContentLoaded', function () {
    renderMaintenanceTable(window.maintenanceHistory);
});

