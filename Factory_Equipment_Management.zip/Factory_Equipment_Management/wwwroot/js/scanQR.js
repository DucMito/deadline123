﻿function showItemInfo(item) {
    let html = `
        <h3>Thông tin thiết bị</h3>
        <ul>
            <li><b>ID:</b> ${item.id}</li>
            <li><b>Tên thiết bị:</b> ${item.deviceName}</li>
            <li><b>Ngày sử dụng:</b> ${item.activedDate}</li>
            <li><b>Vị trí:</b> ${item.location}</li>
            <li><b>QR Code:</b><br/><img src="${item.qrCodeBase64}" style="max-width:120px"/></li>
            <li><b>Ảnh:</b><br/>${item.imageUrl ? `<img src="${item.imageUrl}" style="max-width:120px"/>` : 'Không có ảnh'}</li>
        </ul>
        <h4>Lịch sử bảo trì</h4>
        <ul>
            ${item.maintenanceHistory && item.maintenanceHistory.length > 0
            ? item.maintenanceHistory.map(x => `<li>
                    <b>Ngày:</b> ${x.dateEnd || ''} -
                    <b>Nhân viên:</b> ${x.staffName || ''} -
                    <b>Lý do:</b> ${x.reason || ''} -
                    <b>Loại:</b> ${x.type || ''} -
                    <b>Chi phí:</b> ${x.budget || 0}
                </li>`).join('')
            : '<li>Không có dữ liệu</li>'
        }
        </ul>
        <div>
            <b>Tổng bảo dưỡng:</b> ${item.totalBaoDuong} |
            <b>Tổng sửa chữa:</b> ${item.totalSuaChua} |
            <b>Tổng chi phí:</b> ${item.totalAll}
        </div>
    `;
    document.getElementById('qr-result').innerHTML = html;
}

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById('startCamera').onclick = function () {
        const qrReader = new Html5Qrcode("qr-reader");
        qrReader.start(
            { facingMode: "environment" },
            { fps: 10, qrbox: 250 },
            qrCodeMessage => {
                fetch('/ScanQR/GetItemByQR?code=' + encodeURIComponent(qrCodeMessage))
    .then(async res => {
        let text = await res.text();
        try {
            let data = JSON.parse(text);
            console.log(data); // Nếu là JSON hợp lệ
            if (data.success) showItemInfo(data.item);
            else document.getElementById('qr-result').innerText = data.message + (data.detail ? "\n" + data.detail : "");
        } catch (err) {
            // Nếu không phải JSON, log ra nội dung trả về để debug
            console.error("Lỗi parse JSON:", err);
            console.error("Nội dung trả về:", text);
            document.getElementById('qr-result').innerText = "Lỗi server!\n" + text;
        }
    });
                qrReader.stop();
            }
        );
    };

    document.getElementById('qrImageInput').onchange = function (e) {
        const file = e.target.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('file', file);
        fetch('/ScanQR/UploadImage', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    fetch('/ScanQR/GetItemByQR?code=' + encodeURIComponent(data.result))
                        .then(res => res.json())
                        .then(data2 => {
                            if (data2.success) showItemInfo(data2.item);
                            else document.getElementById('qr-result').innerText = data2.message;
                        });
                } else {
                    document.getElementById('qr-result').innerText = data.message || "Không nhận diện được QR!";
                }
            });
    };
});