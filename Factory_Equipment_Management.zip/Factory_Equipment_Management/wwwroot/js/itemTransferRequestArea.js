﻿document.addEventListener('DOMContentLoaded', function () {
    function fetchAndRenderDevices(warehouse, area) {
        if (!warehouse || !area) {
            renderDeviceTable([]);
            return;
        }
        fetch(`/ItemTransferRequestArea/GetDevices?warehouse=${encodeURIComponent(warehouse)}&area=${encodeURIComponent(area)}`)
            .then(res => res.json())
            .then(data => {
                renderDeviceTable(data.items);
            });
    }

    function renderDeviceTable(devices) {
        const tbody = document.querySelector('.transfer-table tbody');
        tbody.innerHTML = '';
        if (!devices || devices.length === 0) {
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.colSpan = 4;
            td.textContent = 'Không có dữ liệu';
            tr.appendChild(td);
            tbody.appendChild(tr);
            return;
        }
        devices.forEach(device => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${device.Id ?? ''}</td>
                <td>${device.DeviceType ?? ''}</td>
                <td>${device.Status ?? ''}</td>
                <td>${device.ActivedDate ?? ''}</td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Gọi fetchAndRenderDevices với giá trị mặc định hoặc khi người dùng chọn warehouse/area
    // Ví dụ:
    // fetchAndRenderDevices('PKG', 'Khu rửa');
});