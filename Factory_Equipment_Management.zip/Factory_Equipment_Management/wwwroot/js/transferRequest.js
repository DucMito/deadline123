﻿document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.approve-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = btn.getAttribute('data-id');
            fetch(`/Home/ApproveTransferRequest/${id}`, { method: 'POST' })
                .then(async res => {
                    if (res.ok) {
                        location.reload();
                    } else {
                        const msg = await res.text();
                        alert(msg || 'Lỗi xử lý!');
                    }
                });
        });
    });
    document.querySelectorAll('.reject-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = btn.getAttribute('data-id');
            fetch(`/Home/RejectTransferRequest/${id}`, { method: 'POST' })
                .then(async res => {
                    if (res.ok) {
                        location.reload();
                    } else {
                        const msg = await res.text();
                        alert(msg || 'Lỗi xử lý!');
                    }
                });
        });
    });
});