﻿document.addEventListener("DOMContentLoaded", function () {
    // Xử lý chi tiết thiết bị

    // Mở popup thêm thiết bị
    var btnAddDevice = document.getElementById('btnAddDevice');
    var addDeviceModal = document.getElementById('addDeviceModal');
    var closeAddDeviceModal = document.getElementById('closeAddDeviceModal');

    if (btnAddDevice && addDeviceModal && closeAddDeviceModal) {
        btnAddDevice.onclick = function () {
            addDeviceModal.style.display = 'block';
        };
        closeAddDeviceModal.onclick = function () {
            addDeviceModal.style.display = 'none';
        };
        window.onclick = function (event) {
            if (event.target === addDeviceModal) {
                addDeviceModal.style.display = 'none';
            }
        };
    }

    // Hiển thị alert khi thêm thiết bị thành công/thất bại
    var alertMsg = document.getElementById('alert-message-data');
    if (alertMsg && alertMsg.value) {
        alert(alertMsg.value);
    }
});