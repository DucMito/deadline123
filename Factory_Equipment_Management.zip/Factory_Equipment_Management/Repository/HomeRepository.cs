﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Factory_Equipment_Management.Repository
{
    public class HomeRepository
    {
        private readonly YourDbContext _context;
        public HomeRepository(YourDbContext context)
        {
            _context = context;
        }

        // Lấy danh sách theo trạng thái (status)
        public List<MaintanceRequestDisplayModel> GetRequestsByStatus(string status = null)
        {
            var query = from mr in _context.MaintanceRequests
                        join i in _context.Items on mr.idItem equals i.idItem into itemJoin
                        from i in itemJoin.DefaultIfEmpty()
                        join c in _context.Categories on i.idCategory equals c.idCategory into catJoin
                        from c in catJoin.DefaultIfEmpty()
                        join p in _context.PICs on mr.idPIC equals p.idPIC into picJoin
                        from p in picJoin.DefaultIfEmpty()
                        join a in _context.Areas on i.idArea equals a.idArea into areaJoin
                        from a in areaJoin.DefaultIfEmpty()
                        join w in _context.Warehouses on a.idWarehouse equals w.idWarehouse into wareJoin
                        from w in wareJoin.DefaultIfEmpty()
                        orderby mr.date descending
                        select new MaintanceRequestDisplayModel
                        {
                            idMaintanceRequest = mr.idMaintanceRequest,
                            date = mr.date,
                            categoryName = c.name,
                            idCategory = i.idCategory,
                            idItem = i.idItem,
                            staffName = p.name,
                            status = mr.status,
                            reason = mr.reason,
                            budgetEstimate = mr.budgetEstimate,
                            type = mr.type,
                            image = mr.image,
                            areaName = a.name,
                            warehouseName = w.name,
                            idArea = a.idArea,
                            idWarehouse = w.idWarehouse,
                            extend = mr.extend.ToString(),
                            email = p.email,
                            typeCategory = i.type
                        };

            // Lọc theo trạng thái
            if (!string.IsNullOrEmpty(status) && status != "Tất cả")
            {
                // "Bảo trì" là trạng thái "Bảo dưỡng"
                if (status == "Bảo trì")
                    query = query.Where(x => x.status == "Bảo dưỡng");
                // Các nút còn lại lọc đúng trạng thái
                else if (status == "Chấp nhận")
                    query = query.Where(x => x.status == "Chấp nhận");
                else if (status == "Đang chờ")
                    query = query.Where(x => x.status == "Đang chờ");
                else if (status == "Từ chối")
                    query = query.Where(x => x.status == "Từ chối");
                else if (status == "Sửa chữa")
                    query = query.Where(x => x.status == "Sửa chữa");
                else if (status == "Thay mới")
                    query = query.Where(x => x.status == "Thay mới");
                else if (status == "Gia hạn")
                    query = query.Where(x => x.status == "Gia hạn");
                // Nếu muốn thêm trạng thái khác, bổ sung tại đây
            }

            return query.ToList();
        }

        // code chức năng transferRequest
        public List<TranferRequest> GetAllTransferRequests(
                    int? id, int? idPic, string status, int pageNumber, int pageSize, out int totalCount)
        {
            var query = _context.TranferRequests.AsQueryable();

            if (id.HasValue)
                query = query.Where(x => x.idTranferRequest == id.Value);

            if (idPic.HasValue)
                query = query.Where(x => x.PIC_request == idPic.Value);

            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            totalCount = query.Count();

            return query
                .OrderByDescending(x => x.date)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }

        // Duyệt đơn: Chấp nhận
        public bool ApproveTransferRequest(int id, int currentUserId, string currentUserRole)
        {
            var request = _context.TranferRequests.FirstOrDefault(x => x.idTranferRequest == id);
            if (request == null) return false;

            var area = _context.Areas.FirstOrDefault(a => a.idArea == request.toArea);
            if (area == null) return false;

            var warehouse = _context.Warehouses.FirstOrDefault(w => w.idWarehouse == area.idWarehouse);
            if (warehouse == null) return false;

            // Quyền duyệt
            if (currentUserRole == "Staff")
                throw new Exception("Staff không có quyền duyệt đơn.");

            if (currentUserRole == "PIC")
            {
                if (warehouse.idPIC != currentUserId)
                    throw new Exception("Bạn không phải PIC của kho đích, không được duyệt đơn này.");
            }
            // Admin/Manager: toàn quyền, không kiểm tra

            var details = _context.TranferRequestDetails
                .Where(d => d.idTranferRequest == id)
                .ToList();

            foreach (var detail in details)
            {
                var item = _context.Items.FirstOrDefault(i => i.idItem == detail.idItem);
                if (item != null)
                {
                    item.idArea = request.toArea;
                }
            }

            var history = new TranferHistory
            {
                sender = request.PIC_request,
                receiver = warehouse.idPIC,
                date = DateTime.Now,
                idTranferRequest = id,
                senderType = "PIC",
                receiverType = "PIC"
            };
            _context.TranferHistories.Add(history);

            request.status = "Chấp nhận";
            request.date_answer = DateTime.Now;
            _context.SaveChanges();
            return true;
        }

        // Duyệt đơn: Từ chối
        public bool RejectTransferRequest(int id, int currentUserId, string currentUserRole)
        {
            var request = _context.TranferRequests.FirstOrDefault(x => x.idTranferRequest == id);
            if (request == null) return false;

            var area = _context.Areas.FirstOrDefault(a => a.idArea == request.toArea);
            if (area == null) return false;

            var warehouse = _context.Warehouses.FirstOrDefault(w => w.idWarehouse == area.idWarehouse);
            if (warehouse == null) return false;

            // Quyền duyệt
            if (currentUserRole == "Staff")
                throw new Exception("Staff không có quyền duyệt đơn.");

            if (currentUserRole == "PIC")
            {
                if (warehouse.idPIC != currentUserId)
                    throw new Exception("Bạn không phải PIC của kho đích, không được duyệt đơn này.");
            }
            // Admin/Manager: toàn quyền, không kiểm tra

            request.status = "Từ chối";
            request.date_answer = DateTime.Now;
            _context.SaveChanges();
            return true;
        }

        public List<Area> GetAreasByWarehouseName(string warehouseName)
        {
            var warehouse = _context.Warehouses.FirstOrDefault(w => w.name == warehouseName);
            if (warehouse == null) return new List<Area>();
            return _context.Areas.Where(a => a.idWarehouse == warehouse.idWarehouse).ToList();
        }
    }
}