﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Factory_Equipment_Management.Repository
{
    public class RegisterDeviceRepository
    {
        private readonly YourDbContext _context;
        public RegisterDeviceRepository(YourDbContext context)
        {
            _context = context;
        }


        public List<RegisterDeviceListItemViewModel> GetRegisterDeviceList(int page, int pageSize, out int totalCount, string status = null)
        {
            var query = from device in _context.RegisterDevices
                        join request in _context.RegisterDeviceRequests
                            on device.idRegisterDeviceRequest equals request.idRegisterDeviceRequest
                        select new RegisterDeviceListItemViewModel
                        {
                            idRegisterDevice = device.idRegisterDevice,
                            name = device.name,
                            num = device.num,
                            status = request.status,
                            date = request.date
                        };

            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            totalCount = query.Count();

            return query
                .OrderByDescending(x => x.date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }

        public bool AddRegisterDevice(RegisterDeviceCreateViewModel model)
        {
            using var transaction = _context.Database.BeginTransaction();
            try
            {
                // 1. RealCategory
                var realCategory = _context.RealCategories
                    .FirstOrDefault(rc => rc.idRealCategory == model.IdRealCategory.Value);
                if (realCategory == null)
                {
                    realCategory = new RealCategory
                    {
                        idRealCategory = model.IdRealCategory.Value,
                        name = "No data"
                    };
                    _context.RealCategories.Add(realCategory);
                    _context.SaveChanges();
                }

                // 2. Category
                var category = _context.Categories
                    .FirstOrDefault(c => c.idCategory == model.CategoryId);
                if (category == null)
                {
                    category = new Category
                    {
                        idCategory = model.CategoryId,
                        name = model.Name,
                        idrealCategory = realCategory.idRealCategory,
                        alertMaintance = model.AlertMaintaince.HasValue ? (double)model.AlertMaintaince.Value : 0,
                        alertRenew = model.AlertRenew.HasValue ? (double)model.AlertRenew.Value : 0
                    };
                    _context.Categories.Add(category);
                    _context.SaveChanges();
                }
                else
                {
                    category.name = model.Name;
                    _context.Categories.Update(category);
                    _context.SaveChanges();
                }

                // 3. RegisterDeviceRequest (tạo mới mỗi lần)
                var request = new RegisterDeviceRequest
                {
                    date = DateTime.Now,
                    status = "pending"
                };
                _context.RegisterDeviceRequests.Add(request);
                _context.SaveChanges();

                // 4. Xử lý ảnh sang hex
                string imageHex = "No data";
                if (model.Image != null && model.Image.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        model.Image.CopyTo(ms);
                        var bytes = ms.ToArray();
                        imageHex = BitConverter.ToString(bytes).Replace("-", "");
                    }
                }

                // 5. RegisterDevice
                var device = new RegisterDevice
                {
                    idCategory = category.idCategory,
                    name = model.Name,
                    num = model.Num,
                    image = imageHex,
                    idRegisterDeviceRequest = request.idRegisterDeviceRequest,
                    maintanceCycle = model.MaintainceCycle.HasValue ? (int)model.MaintainceCycle.Value : 0,
                    renewCycle = model.RenewCycle.HasValue ? (int)model.RenewCycle.Value : 0,
                    po = model.PO,
                    alertMaintance = model.AlertMaintaince.HasValue ? (int)model.AlertMaintaince.Value : 0,
                    alertRenew = model.AlertRenew.HasValue ? (int)model.AlertRenew.Value : 0,
                    dangKiem = model.DangKiemDate,
                    type = model.Type == 1,
                    idRealCategory = realCategory.idRealCategory,
                    realCategoryName = realCategory.name
                };
                _context.RegisterDevices.Add(device);
                _context.SaveChanges();



                // 6. Lưu vào bảng item (num bản ghi)
                for (int i = 0; i < model.Num; i++)
                {
                    var item = new Item
                    {
                        // idItem tự tăng
                        idCategory = category.idCategory,
                        image = imageHex,
                        duration = 0, // hoặc giá trị mặc định phù hợp
                        maintanceCycle = model.MaintainceCycle.HasValue ? (float)model.MaintainceCycle.Value : 0,
                        active = false,
                        status = "Dự phòng",
                        receivedDate = null,
                        activedDate = null,
                        idArea = null,
                        maintanceDate = null,
                        renewDate = null,
                        maintanceRequested = false,
                        po = model.PO ?? "No data",
                        dangKiem = model.DangKiemDate,
                        type = model.Type,
                        contractor = "No data",
                        serialNumber = "No data",
                        supplier = "No data",
                        comment = "No data"
                    };
                    _context.Items.Add(item);
                }
                _context.SaveChanges();

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                return false;
            }
        }



        // phân trang 
        public async Task<(List<RegisterDeviceRequestModel> Requests, int TotalCount)> GetPagedRequestsAsync(int page, int pageSize, string status)
        {
            var query = _context.RegisterDeviceRequests.AsQueryable();
            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            int totalCount = await query.CountAsync();

            var data = await query
                .OrderByDescending(x => x.date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (data.Select(x => new RegisterDeviceRequestModel
            {
                idRegisterDeviceRequest = x.idRegisterDeviceRequest,
                date = x.date,
                status = x.status
            }).ToList(), totalCount);
        }

    }
}