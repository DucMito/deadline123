﻿using Factory_Equipment_Management.ViewModel;
using Factory_Equipment_Management.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Factory_Equipment_Management.Models;

public class ItemTransferRequestAreaRepository
{
    private readonly YourDbContext _context;

    public ItemTransferRequestAreaRepository(YourDbContext context)
    {
        _context = context;
    }

    public async Task<ItemTransferRequestAreaViewModel> GetViewModelAsync()
    {
        var warehouses = await _context.Warehouses.Select(w => w.name.Trim()).ToListAsync();

        var warehouseAreas = new Dictionary<string, List<string>>();
        foreach (var warehouse in await _context.Warehouses.ToListAsync())
        {
            var areas = await _context.Areas
                .Where(a => a.idWarehouse == warehouse.idWarehouse)
                .Select(a => a.name)
                .ToListAsync();
            warehouseAreas[warehouse.name.Trim()] = areas;
        }

        var selectedWarehouse = warehouses.FirstOrDefault();
        var areasForSelected = selectedWarehouse != null && warehouseAreas.ContainsKey(selectedWarehouse)
            ? warehouseAreas[selectedWarehouse]
            : new List<string>();

        var model = new ItemTransferRequestAreaViewModel
        {
            Warehouses = warehouses,
            WarehouseAreas = warehouseAreas,
            SelectedWarehouse = selectedWarehouse,
            Areas = areasForSelected // <-- Gán danh sách area cho select
        };

        return model;
    }

    // Lấy danh sách thiết bị nhóm theo loại (category), chỉ lấy các thiết bị chưa có area (i.idArea IS NULL)
    public async Task<List<TransferDeviceModel>> GetDeviceQuantitiesAsync()
    {
        var query = from i in _context.Set<Item>()
                    join c in _context.Categories on i.idCategory equals c.idCategory into cat
                    from c in cat.DefaultIfEmpty()
                    where i.idArea == null
                    group new { i, c } by new { i.idCategory, c.name, c.idrealCategory } into g
                    orderby g.Key.idrealCategory
                    select new TransferDeviceModel
                    {
                        Id = g.Key.idCategory ?? 0,
                        DeviceType = g.Key.name,
                        ImageUrl = g.Max(x => x.i.image),
                        Quantity = g.Count(),
                        TransferQuantity = 0
                    };

        return await query.ToListAsync();
    }

    private string HexToBase64(string hex)
    {
        if (string.IsNullOrEmpty(hex)) return "";
        try
        {
            byte[] bytes = Enumerable.Range(0, hex.Length / 2)
                .Select(x => Convert.ToByte(hex.Substring(x * 2, 2), 16))
                .ToArray();
            return Convert.ToBase64String(bytes);
        }
        catch
        {
            return "";
        }
    }

    public async Task<List<TransferDeviceModel>> GetDevicesByWarehouseAndAreaAsync(string warehouse, string area)
    {
        var query = from i in _context.Items
                    join c in _context.Categories on i.idCategory equals c.idCategory
                    join a in _context.Areas on i.idArea equals a.idArea
                    join w in _context.Warehouses on a.idWarehouse equals w.idWarehouse
                    where w.name.Trim().ToLower() == warehouse.Trim().ToLower()
                       && a.name.Trim().ToLower() == area.Trim().ToLower()
                    select new
                    {
                        i.idItem,
                        c.name,
                        i.status,
                        i.activedDate
                    };

        var list = await query.ToListAsync();

        return list.Select(x => new TransferDeviceModel
        {
            Id = x.idItem ?? 0,
            DeviceType = x.name,
            Status = x.status,
            ActivedDate = x.activedDate.HasValue ? x.activedDate.Value.ToString("yyyy-MM-dd") : ""
        }).ToList();
    }

    public async Task<(List<TransferDeviceModel> Items, int TotalCount)> GetDevicesByWarehouseAndAreaPagedAsync(string warehouse, string area, int page, int pageSize)
    {
        var query = from i in _context.Set<Item>()
                    join c in _context.Categories on i.idCategory equals c.idCategory
                    join a in _context.Areas on i.idArea equals a.idArea
                    join w in _context.Warehouses on a.idWarehouse equals w.idWarehouse
                    where w.name == warehouse && a.name == area
                    select new
                    {
                        i.idItem, // <-- Lấy idItem
                        c.name,
                        i.image,
                        i.status,
                        i.activedDate
                    };

        var totalCount = await query.CountAsync();

        var list = await query
            .OrderBy(x => x.idItem)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var items = list.Select(x => new TransferDeviceModel
        {
            Id = x.idItem ?? 0, // Trả về idItem, nếu null thì gán 0
            DeviceType = x.name,
            ImageUrl = string.IsNullOrEmpty(x.image) ? "" : $"data:image/jpeg;base64,{HexToBase64(x.image)}",
            Status = x.status,
            ActivedDate = x.activedDate.HasValue ? x.activedDate.Value.ToString("yyyy-MM-dd") : ""
        }).ToList();

        return (items, totalCount);
    }

    // Hàm cũ vẫn giữ lại cho các chỗ khác nếu cần
    public async Task<List<TransferDeviceModel>> GetNewProductsAsync()
    {
        var query = from i in _context.Set<Item>()
                    join c in _context.Categories on i.idCategory equals c.idCategory into cat
                    from c in cat.DefaultIfEmpty()
                    where i.idArea == null
                    select new
                    {
                        idCategory = c != null ? c.idCategory : 0,
                        name = c != null ? c.name : "",
                        i.image,
                        i.status,
                        i.activedDate
                    };

        var list = await query.ToListAsync();

        return list.Select(x => new TransferDeviceModel
        {
            Id = x.idCategory,
            DeviceType = x.name,
            ImageUrl = string.IsNullOrEmpty(x.image) ? "" : $"data:image/jpeg;base64,{HexToBase64(x.image)}",
            Status = x.status,
            ActivedDate = x.activedDate.HasValue ? x.activedDate.Value.ToString("yyyy-MM-dd") : ""
        }).ToList();
    }

    public async Task<(List<TransferDeviceModel> Items, int TotalCount)> GetNewProductsPagedAsync(int page, int pageSize)
    {
        var query = from i in _context.Set<Item>()
                    join c in _context.Categories on i.idCategory equals c.idCategory into cat
                    from c in cat.DefaultIfEmpty()
                    where i.idArea == null
                    select new
                    {
                        idCategory = c != null ? c.idCategory : 0,
                        name = c != null ? c.name : "",
                        i.image,
                        i.status,
                        i.activedDate
                    };

        var totalCount = await query.CountAsync();

        var list = await query
            .OrderBy(x => x.idCategory)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var items = list.Select(x => new TransferDeviceModel
        {
            Id = x.idCategory,
            DeviceType = x.name,
            ImageUrl = string.IsNullOrEmpty(x.image) ? "" : $"data:image/jpeg;base64,{HexToBase64(x.image)}",
            Status = x.status,
            ActivedDate = x.activedDate.HasValue ? x.activedDate.Value.ToString("yyyy-MM-dd") : ""
        }).ToList();

        return (items, totalCount);
    }

    public async Task<List<MaintanceRequestDisplayModel>> GetAllRequestsAsync()
    {
        var query = from mr in _context.MaintanceRequests
                    join i in _context.Items on mr.idItem equals i.idItem into itemJoin
                    from i in itemJoin.DefaultIfEmpty()
                    join c in _context.Categories on i.idCategory equals c.idCategory into catJoin
                    from c in catJoin.DefaultIfEmpty()
                    join p in _context.PICs on mr.idPIC equals p.idPIC into picJoin
                    from p in picJoin.DefaultIfEmpty()
                    join a in _context.Areas on i.idArea equals a.idArea into areaJoin
                    from a in areaJoin.DefaultIfEmpty()
                    join w in _context.Warehouses on a.idWarehouse equals w.idWarehouse into wareJoin
                    from w in wareJoin.DefaultIfEmpty()
                    orderby mr.date descending
                    select new MaintanceRequestDisplayModel
                    {
                        idMaintanceRequest = mr.idMaintanceRequest,
                        date = mr.date,
                        categoryName = c.name,
                        idCategory = i.idCategory,
                        idItem = i.idItem,
                        staffName = p.name,
                        status = mr.status,
                        reason = mr.reason,
                        budgetEstimate = mr.budgetEstimate,
                        type = mr.type,
                        image = mr.image,
                        areaName = a.name,
                        warehouseName = w.name,
                        idArea = a.idArea,
                        idWarehouse = w.idWarehouse,
                        extend = mr.extend.ToString(),
                        email = p.email,
                        typeCategory = i.type
                    };

        return await query.ToListAsync();
    }

    public async Task<bool> CreateTransferRequestAsync(TransferRequestInputModel model)
    {
        int senderPICId = 0;
        if (model.SenderType == "PIC")
        {
            senderPICId = int.Parse(model.Sender);
            var senderPIC = await _context.PICs.FirstOrDefaultAsync(p => p.idPIC == senderPICId);
            if (senderPIC == null)
                throw new Exception("Tài khoản không hợp lệ để tạo yêu cầu bàn giao.");
        }
        else
        {
            int.TryParse(model.Sender, out senderPICId);
        }

        var toAreaEntity = await _context.Areas.FirstOrDefaultAsync(a => a.name == model.Area);
        var warehouseEntity = await _context.Warehouses.FirstOrDefaultAsync(w => w.name == model.Warehouse);

        if (model.SenderType == "PIC")
        {
            if (warehouseEntity == null || warehouseEntity.idPIC != senderPICId)
                throw new Exception("Bạn không có quyền tạo yêu cầu cho kho này.");
        }

        Area fromAreaEntity = null;
        if (!string.IsNullOrEmpty(model.FromArea))
        {
            fromAreaEntity = await _context.Areas.FirstOrDefaultAsync(a => a.name == model.FromArea);
        }

        if (toAreaEntity == null || warehouseEntity == null)
            return false;

        var receiverPIC = await _context.PICs.FirstOrDefaultAsync(p => p.idPIC == warehouseEntity.idPIC);
        int? receiverPICId = receiverPIC?.idPIC;

        bool isPIC = string.Equals(model.SenderType, "PIC", StringComparison.OrdinalIgnoreCase);

        var transferRequest = new TranferRequest
        {
            PIC_request = isPIC ? senderPICId : (int?)null,
            status = "Đang chờ",
            reason = model.Reason,
            fromArea = fromAreaEntity?.idArea ?? 0,
            toArea = toAreaEntity.idArea,
            date = DateTime.Now,
            date_answer = null,
            createdByRole = model.SenderType,
            createdById = int.TryParse(model.Sender, out var id) ? id : (int?)null
        };
        _context.TranferRequests.Add(transferRequest);
        await _context.SaveChangesAsync();

        foreach (var itemId in model.ItemIds)
        {
            var history = new TranferHistory
            {
                sender = senderPICId,
                senderType = model.SenderType,
                receiver = receiverPICId,
                receiverType = "pic",
                date = DateTime.Now,
                idTranferRequest = (int)transferRequest.idTranferRequest
            };
            _context.TranferHistories.Add(history);
        }
        await _context.SaveChangesAsync();

        // --- Thêm đoạn này để cập nhật lại area cho thiết bị ---
        foreach (var itemId in model.ItemIds)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == itemId);
            if (item != null)
            {
                item.idArea = toAreaEntity.idArea;
            }
        }
        await _context.SaveChangesAsync();
        return true;
    }
}