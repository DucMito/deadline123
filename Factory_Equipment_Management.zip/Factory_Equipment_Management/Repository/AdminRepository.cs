﻿using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Factory_Equipment_Management.Models;

namespace Factory_Equipment_Management.Repository
{
    public class AdminRepository
    {
        private readonly YourDbContext _context;
        public AdminRepository(YourDbContext context)
        {
            _context = context;
        }

        // Validate username: không null, không chỉ chứa khoảng trắng, bỏ khoảng trắng đầu cuối
        private static string? ValidateAndTrimUsername(string username)
        {
            if (username == null) return "Username not null.";
            username = username.Trim();
            if (username.Length == 0) return "Username không được để trống hoặc chỉ chứa khoảng trắng.";
            return null;
        }

        // Validate name: không null, không chỉ chứa khoảng trắng, bỏ khoảng trắng đầu cuối
        private static string? ValidateAndTrimName(string name)
        {
            if (name == null) return "Username not null.";
            name = name.Trim();
            if (name.Length == 0) return "Tên không được để trống hoặc chỉ chứa khoảng trắng.";
            return null;
        }

        // Validate email: không null, không chỉ chứa khoảng trắng, bỏ khoảng trắng đầu cuối, kết thúc bằng @ap.denso.com
        private static string? ValidateAndTrimEmail(string email)
        {
            if (email == null) return "Email không được để trống.";
            email = email.Trim();
            if (email.Length == 0) return "Email không được để trống hoặc chỉ chứa khoảng trắng.";
            if (!email.EndsWith("@ap.denso.com", StringComparison.OrdinalIgnoreCase))
                return "Email phải có đuôi @ap.denso.com.";
            return null;
        }

        public (string role, int id) ValidateUser(string username, string password)
        {
            // Bỏ khoảng trắng đầu cuối username và password
            username = username?.Trim();
            password = password?.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return (null, 0);

            string hashedPassword = HashPassword(password);

            // Kiểm tra Manager/Admin
            var manager = _context.Managers.FirstOrDefault(m => m.username == username && m.password == hashedPassword);
            if (manager != null)
            {
                if (manager.admin)
                    return ("Admin", manager.idManager);
                if (manager.active)
                    return ("Manager", manager.idManager);
            }

            // Kiểm tra PIC (không phân biệt AccountantPIC)
            var pic = _context.PICs.FirstOrDefault(p => p.username == username && p.password == hashedPassword);
            if (pic != null)
            {
                return ("PIC", pic.idPIC);
            }

            // Kiểm tra Staff
            var staff = _context.Staffs.FirstOrDefault(s => s.username == username && s.password == hashedPassword);
            if (staff != null)
                return ("Staff", staff.idStaff);

            return (null, 0);
        }

        public static string HashPassword(string password)
        {
            if (password == null) return null;
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        public List<Staff> GetAllStaff()
        {
            return _context.Staffs
                .Select(s => new Staff {
                    idStaff = s.idStaff,
                    name = s.name,
                    username = s.username,
                    password = s.password, // Trả về password gốc
                    email = s.email
                }).ToList();
        }

        public Staff GetStaffById(int id)
        {
            return _context.Staffs.FirstOrDefault(s => s.idStaff == id);
        }

        // Trả về null nếu thành công, trả về thông báo lỗi nếu có lỗi
        public string? UpdateStaff(Staff staff)
        {
            var existing = _context.Staffs.FirstOrDefault(s => s.idStaff == staff.idStaff);
            if (existing == null) return "Không tìm thấy nhân viên.";
            var nameError = ValidateAndTrimName(staff.name);
            if (nameError != null) return nameError;
            var usernameError = ValidateAndTrimUsername(staff.username);
            if (usernameError != null) return usernameError;
            var emailError = ValidateAndTrimEmail(staff.email);
            if (emailError != null) return emailError;

            // Cập nhật các trường
            existing.name = staff.name.Trim();
            existing.username = staff.username.Trim();
            existing.email = staff.email.Trim();

            // Nếu password thay đổi, hash lại
            if (!string.IsNullOrEmpty(staff.password) && staff.password != existing.password)
                existing.password = HashPassword(staff.password);

            _context.SaveChanges();
            return null;
        }

        public void DeleteStaff(int id)
        {
            var staff = _context.Staffs.FirstOrDefault(s => s.idStaff == id);
            if (staff != null)
            {
                _context.Staffs.Remove(staff);
                _context.SaveChanges();
            }
        }

        // Trả về null nếu thành công, trả về thông báo lỗi nếu có lỗi
        public string? AddStaff(Staff staff)
        {
            var nameError = ValidateAndTrimName(staff.name);
            if (nameError != null) return nameError;
            var usernameError = ValidateAndTrimUsername(staff.username);
            if (usernameError != null) return usernameError;
            var emailError = ValidateAndTrimEmail(staff.email);
            if (emailError != null) return emailError;

            staff.name = staff.name.Trim();
            staff.username = staff.username.Trim();
            staff.email = staff.email.Trim();
            staff.password = HashPassword(staff.password);

            _context.Staffs.Add(staff);
            _context.SaveChanges();
            return null;
        }


        public List<PIC> GetAllPICs() => _context.PICs.ToList();

        public string? AddPic(PIC pic)
        {
            if (string.IsNullOrWhiteSpace(pic.name)) return "Tên không được để trống.";
            if (string.IsNullOrWhiteSpace(pic.username)) return "Username không được để trống.";
            if (string.IsNullOrWhiteSpace(pic.email)) return "Email không được để trống.";

            pic.name = pic.name.Trim();
            pic.username = pic.username.Trim();
            pic.email = pic.email.Trim();

            // Kiểm tra trùng username hoặc email
            if (_context.PICs.Any(p => p.username == pic.username))
                return "Username đã tồn tại.";
            if (_context.PICs.Any(p => p.email == pic.email))
                return "Email đã tồn tại.";

            pic.password = AdminRepository.HashPassword(pic.password);

            _context.PICs.Add(pic);
            _context.SaveChanges();
            return null;
        }

        public string? UpdatePic(PIC pic)
        {
            Console.WriteLine($"UpdatePic: idPIC={pic.idPIC}, name={pic.name}, username={pic.username}");
            var existing = _context.PICs.FirstOrDefault(s => s.idPIC == pic.idPIC);
            if (existing == null) return "Không tìm thấy PIC.";

            var nameError = ValidateAndTrimName(pic.name);
            if (nameError != null) return nameError;
            var usernameError = ValidateAndTrimUsername(pic.username);
            if (usernameError != null) return usernameError;
            var emailError = ValidateAndTrimEmail(pic.email);
            if (emailError != null) return emailError;

            // Kiểm tra trùng username/email (trừ chính mình)
            if (_context.PICs.Any(p => p.username == pic.username && p.idPIC != pic.idPIC))
                return "Username đã tồn tại.";
            if (_context.PICs.Any(p => p.email == pic.email && p.idPIC != pic.idPIC))
                return "Email đã tồn tại.";

            existing.name = pic.name.Trim();
            existing.username = pic.username.Trim();
            existing.email = pic.email.Trim();

            // Nếu password thay đổi và khác hash cũ, hash lại
            if (!string.IsNullOrEmpty(pic.password) && pic.password != existing.password)
            {
                existing.password = HashPassword(pic.password);
            }

            _context.SaveChanges();
            return null;
        }

        public void DeletePic(int id)
        {
            var pic = _context.PICs.FirstOrDefault(p => p.idPIC == id);
            if (pic != null)
            {
                _context.PICs.Remove(pic);
                _context.SaveChanges();
            }
        }



        public List<Manager> GetAllManagers() => _context.Managers.ToList();

        public string? AddManager(Manager manager)
        {
            if (string.IsNullOrWhiteSpace(manager.name)) return "Tên không được để trống.";
            if (string.IsNullOrWhiteSpace(manager.username)) return "Username không được để trống.";
            if (string.IsNullOrWhiteSpace(manager.email)) return "Email không được để trống.";
            manager.name = manager.name.Trim();
            manager.username = manager.username.Trim();
            manager.email = manager.email.Trim();
            manager.password = AdminRepository.HashPassword(manager.password);
            _context.Managers.Add(manager);
            _context.SaveChanges();
            return null;
        }

        public string? UpdateManager(Manager manager)
        {
            var existing = _context.Managers.FirstOrDefault(s => s.idManager == manager.idManager);
            if (existing == null) return "Không tìm thấy Manager.";
            var nameError = ValidateAndTrimName(manager.name);
            if (nameError != null) return nameError;
            var usernameError = ValidateAndTrimUsername(manager.username);
            if (usernameError != null) return usernameError;
            var emailError = ValidateAndTrimEmail(manager.email);
            if (emailError != null) return emailError;

            // Cập nhật các trường
            existing.name = manager.name.Trim();
            existing.username = manager.username.Trim();
            existing.email = manager.email.Trim();

            // Nếu password thay đổi, hash lại
            if (!string.IsNullOrEmpty(manager.password))
            {
                if (manager.password != existing.password)
                    existing.password = HashPassword(manager.password);
            }

            _context.SaveChanges();
            return null;
        }

        public void DeleteManager(int id)
        {
            var manager = _context.Managers.FirstOrDefault(m => m.idManager == id);
            if (manager != null)
            {
                _context.Managers.Remove(manager);
                _context.SaveChanges();
            }
        }

        public List<Warehouse> GetAllWarehouses() => _context.Warehouses.ToList();


        public string? AddWarehouse(Warehouse warehouse)
        {
            if (string.IsNullOrWhiteSpace(warehouse.name)) return "Tên kho không được để trống.";
            warehouse.name = warehouse.name.Trim();
            _context.Warehouses.Add(warehouse);
            _context.SaveChanges();
            return null;
        }

        // Warehouse
        public string? UpdateWarehouse(Warehouse warehouse)
        {
            var existing = _context.Warehouses.FirstOrDefault(w => w.idWarehouse == warehouse.idWarehouse);
            if (existing == null) return "Không tìm thấy kho.";
            existing.name = warehouse.name?.Trim();
            existing.idPIC = warehouse.idPIC;
            _context.SaveChanges();
            return null;
        }

        public void DeleteWarehouse(int idWarehouse)
        {
            var warehouse = _context.Warehouses.FirstOrDefault(w => w.idWarehouse == idWarehouse);
            if (warehouse != null)
            {
                // Xóa luôn các area thuộc warehouse này (nếu muốn)
                var areas = _context.Areas.Where(a => a.idWarehouse == idWarehouse).ToList();
                _context.Areas.RemoveRange(areas);

                _context.Warehouses.Remove(warehouse);
                _context.SaveChanges();
            }
        }

        public string? AddArea(Area area)
        {
            if (area == null) return "Dữ liệu khu vực không hợp lệ.";
            if (string.IsNullOrWhiteSpace(area.name)) return "Tên khu vực không được để trống.";
            if (area.idWarehouse <= 0) return "Vui lòng chọn kho hợp lệ.";

            area.name = area.name.Trim();

            // Kiểm tra trùng tên khu vực trong cùng một kho (nếu cần)
            bool isDuplicate = _context.Areas.Any(a => a.idWarehouse == area.idWarehouse && a.name == area.name);
            if (isDuplicate) return "Tên khu vực đã tồn tại trong kho này.";

            _context.Areas.Add(area);
            _context.SaveChanges();
            return null;
        }

        // Area
        public string? UpdateArea(Area area)
        {
            var existing = _context.Areas.FirstOrDefault(a => a.idArea == area.idArea);
            if (existing == null) return "Không tìm thấy khu vực.";
            existing.name = area.name?.Trim();
            existing.idWarehouse = area.idWarehouse;
            _context.SaveChanges();
            return null;
        }

        public void DeleteArea(int idArea)
        {
            var area = _context.Areas.FirstOrDefault(a => a.idArea == idArea);
            if (area != null)
            {
                _context.Areas.Remove(area);
                _context.SaveChanges();
            }
        }

        // information user
        public object? GetUserInfo(string role, int id)
        {
            if (role == "Admin" || role == "Manager")
            {
                var manager = _context.Managers.FirstOrDefault(m => m.idManager == id);
                if (manager != null)
                    return new { manager.name, manager.username, manager.email, role = manager.admin ? "Admin" : "Manager" };
            }
            else if (role == "PIC" || role == "AccountantPIC")
            {
                var pic = _context.PICs.FirstOrDefault(p => p.idPIC == id);
                if (pic != null)
                    return new { pic.name, pic.username, pic.email, role = pic.accountantPIC ? "AccountantPIC" : "PIC" };
            }
            else if (role == "Staff")
            {
                var staff = _context.Staffs.FirstOrDefault(s => s.idStaff == id);
                if (staff != null)
                    return new { staff.name, staff.username, staff.email, role = "Staff" };
            }
            return null;
        }
    }
}