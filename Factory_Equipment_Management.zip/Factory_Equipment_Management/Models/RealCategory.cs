﻿namespace Factory_Equipment_Management.Models
{
    public class RealCategory
    {
        public int idRealCategory { get; set; }
        public string name { get; set; }

        public RealCategory() { }

        public RealCategory(int idRealCategory, string name)
        {
            this.idRealCategory = idRealCategory;
            this.name = name;
        }
    }
}
