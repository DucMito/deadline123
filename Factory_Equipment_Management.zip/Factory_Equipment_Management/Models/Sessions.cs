﻿namespace Factory_Equipment_Management.Models
{
    public class Sessions
    {
        public string sid { get; set; }
        public string session { get; set; }
        public int expires { get; set; }

        public Sessions() { }

        public Sessions(string sid, string session, int expires)
        {
            this.sid = sid;
            this.session = session;
            this.expires = expires;
        }
    }
}
