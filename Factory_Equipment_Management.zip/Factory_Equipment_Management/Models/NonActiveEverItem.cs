﻿namespace Factory_Equipment_Management.Models
{
    public class NonActiveEverItem
    {
        public int idNonActive_ever_item { get; set; }
        public int idCategory { get; set; }
        public int idArea { get; set; }

        public NonActiveEverItem() { }

        public NonActiveEverItem(int idNonActive_ever_item, int idCategory, int idArea)
        {
            this.idNonActive_ever_item = idNonActive_ever_item;
            this.idCategory = idCategory;
            this.idArea = idArea;
        }
    }
}
