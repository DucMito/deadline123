﻿namespace Factory_Equipment_Management.Models
{
    public class Warehouse
    {
        public int idWarehouse { get; set; }
        public string name { get; set; }
        public int idPIC { get; set; }

        // Constructor không tham số
        public Warehouse() { }

        // Constructor có tham số
        public Warehouse(int idWarehouse, string name, int idPIC)
        {
            this.idWarehouse = idWarehouse;
            this.name = name;
            this.idPIC = idPIC;
        }
    }
}
