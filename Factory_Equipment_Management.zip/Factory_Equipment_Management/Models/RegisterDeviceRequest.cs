﻿namespace Factory_Equipment_Management.Models
{
    public class RegisterDeviceRequest
    {
        public int idRegisterDeviceRequest { get; set; }
        public DateTime date { get; set; }
        public string status { get; set; }

        // Navigation property: Một yêu cầu có thể có nhiều thiết bị đăng ký
        public ICollection<RegisterDevice> RegisterDevices { get; set; }

        public RegisterDeviceRequest() { }

        public RegisterDeviceRequest(int idRegisterDeviceRequest, DateTime date, string status)
        {
            this.idRegisterDeviceRequest = idRegisterDeviceRequest;
            this.date = date;
            this.status = status;
        }
    }
}