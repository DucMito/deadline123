﻿namespace Factory_Equipment_Management.Models
{
    public class Item
    {
        public int? idItem { get; set; }
        public int? idCategory { get; set; }
        public string image { get; set; }
        public float duration { get; set; }
        public float maintanceCycle { get; set; }
        public bool? active { get; set; }
        public string status { get; set; }
        public DateTime? receivedDate { get; set; }
        public DateTime? activedDate { get; set; }
        public int? idArea { get; set; }
        public DateTime? maintanceDate { get; set; }
        public DateTime? renewDate { get; set; }
        public bool? maintanceRequested { get; set; }
        public string po { get; set; }

        public DateTime? dangKiem { get; set; }
        public int? type { get; set; }


        // Đổi thành property để EF nhận diện
        public string comment { get; set; }
        public string serialNumber { get; set; }
        public string contractor { get; set; }
        public string supplier { get; set; }
    }
}