﻿namespace Factory_Equipment_Management.Models
{
    public class MaintanceHistory
    {
        internal string? reason;

        public int idMaintanceHistory { get; set; }
        public int idItem { get; set; }
        public int idStaff { get; set; }
        public int idMaintanceRequest { get; set; }
        public DateTime dateStart { get; set; }
        public DateTime dateEnd { get; set; }
        public string type { get; set; }
        public decimal budget { get; set; }
        public string roleAccept { get; set; }

        public MaintanceHistory() { }

        public MaintanceHistory(int idMaintanceHistory, int idItem, int idStaff, int idMaintanceRequest, DateTime dateStart,
            DateTime dateEnd, string type, decimal budget, string roleAccept)
        {
            this.idMaintanceHistory = idMaintanceHistory;
            this.idItem = idItem;
            this.idStaff = idStaff;
            this.idMaintanceRequest = idMaintanceRequest;
            this.dateStart = dateStart;
            this.dateEnd = dateEnd;
            this.type = type;
            this.budget = budget;
            this.roleAccept = roleAccept;
        }
    }
}
