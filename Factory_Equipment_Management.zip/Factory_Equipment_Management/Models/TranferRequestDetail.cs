﻿namespace Factory_Equipment_Management.Models
{
    public class TranferRequestDetail
    {
        public int idTranferRequestDetail { get; set; }
        public int idTranferRequest { get; set; }
        public int idItem { get; set; }
        public int PIC { get; set; }

        // Constructor có tham số
        public TranferRequestDetail(int idTranferRequestDetail, int idTranferRequest, int idItem, int PIC)
        {
            this.idTranferRequestDetail = idTranferRequestDetail;
            this.idTranferRequest = idTranferRequest;
            this.idItem = idItem;
            this.PIC = PIC;
        }
        public TranferRequestDetail() { }
    }
}
