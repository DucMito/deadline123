﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Factory_Equipment_Management.Models
{
    public class RegisterDevice
    {
        public int idRegisterDevice { get; set; }
        public int idCategory { get; set; }
        public string name { get; set; }
        public int num { get; set; }
        public string image { get; set; }
        public int idRegisterDeviceRequest { get; set; }
        public int maintanceCycle { get; set; }
        public int renewCycle { get; set; }
        public string po { get; set; }
        public int alertMaintance { get; set; }
        public int alertRenew { get; set; }
        public DateTime? dangKiem { get; set; }
        public bool type { get; set; }
        public int idRealCategory { get; set; }
        public string realCategoryName { get; set; }

        // Navigation property: Thiết bị thuộc về một yêu cầu đăng ký
        [ForeignKey("idRegisterDeviceRequest")]
        public RegisterDeviceRequest RegisterDeviceRequest { get; set; }
    }
}