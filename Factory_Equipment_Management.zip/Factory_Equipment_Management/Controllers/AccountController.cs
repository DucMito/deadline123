﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;

namespace Factory_Equipment_Management.Controllers
{
    public class AccountController : Controller
    {
        private readonly AdminRepository _adminRepository;

        public AccountController(YourDbContext context)
        {
            _adminRepository = new AdminRepository(context);
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            (string role, int id) = _adminRepository.ValidateUser(username, password);
            if (role != null)
            {
                var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Name, username),
            new Claim(ClaimTypes.Role, role),
            new Claim("UserId", id.ToString())
        };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(30)
                };
                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties
                );
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Error = "Sai tài khoản hoặc mật khẩu!";
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult UserInfo()
        {
            var role = User.FindFirstValue(ClaimTypes.Role);
            var idStr = User.FindFirstValue("UserId");
            int id = 0;
            int.TryParse(idStr, out id);
            if (string.IsNullOrEmpty(role) || id == 0)
                return Json(new { error = "Chưa đăng nhập" });

            var userInfo = _adminRepository.GetUserInfo(role, id);
            if (userInfo == null)
                return Json(new { error = "Không tìm thấy thông tin người dùng" });

            return Json(userInfo);
        }
    }
}