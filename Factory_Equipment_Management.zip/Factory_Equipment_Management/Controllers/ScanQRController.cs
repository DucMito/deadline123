﻿using Factory_Equipment_Management.Models;
using Microsoft.AspNetCore.Mvc;
using SkiaSharp;
using ZXing.SkiaSharp;

namespace Factory_Equipment_Management.Controllers
{
    public class ScanQRController : Controller
    {

        private readonly YourDbContext _context;
        private readonly ItemDetailRepository _itemDetailRepository;

        public ScanQRController(YourDbContext context)
        {
            _context = context;
            _itemDetailRepository = new ItemDetailRepository(context);
        }

        [HttpGet]
        public IActionResult ScanQR()
        {
            return View();
        }

        // API nhận mã QR (idItem hoặc mã QR) và trả về thông tin thiết bị
        [HttpGet]
        public async Task<IActionResult> GetItemByQR(string code)
        {
            try
            {
                if (string.IsNullOrEmpty(code))
                    return Json(new { success = false, message = "Không có mã QR." });

                int? id = ParseIdFromQrCode(code);
                if (id == null)
                    return Json(new { success = false, message = "Mã QR không hợp lệ." });

                var itemDetail = await _itemDetailRepository.GetItemDetailAsync(id.Value);
                if (itemDetail == null)
                    return Json(new { success = false, message = "Không tìm thấy thiết bị." });

                return Json(new { success = true, item = itemDetail });
            }
            catch (Exception ex)
            {
                // Trả về lỗi chi tiết cho frontend
                return Json(new
                {
                    success = false,
                    message = "Lỗi server: " + ex.Message,
                    detail = ex.ToString() // Thêm detail để xem stacktrace ở DevTools
                });
            }
        }

        // Hàm parse id từ chuỗi QR code
        private int? ParseIdFromQrCode(string qrContent)
        {
            if (string.IsNullOrEmpty(qrContent))
                return null;

            // Nếu là số thuần
            if (int.TryParse(qrContent, out int id))
                return id;

            // Nếu là dạng Device:613
            if (qrContent.StartsWith("Device:", StringComparison.OrdinalIgnoreCase))
            {
                var idStr = qrContent.Substring(7);
                if (int.TryParse(idStr, out id))
                    return id;
            }

            // Nếu là dạng ID:613;Category:...
            var parts = qrContent.Split(';');
            foreach (var part in parts)
            {
                var trimmed = part.Trim();
                if (trimmed.StartsWith("ID:", StringComparison.OrdinalIgnoreCase))
                {
                    var idStr = trimmed.Substring(3);
                    if (int.TryParse(idStr, out id))
                        return id;
                }
            }
            return null;
        }

        [HttpPost]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return Json(new { success = false, message = "Không có file." });

            try
            {
                using var stream = file.OpenReadStream();
                using var ms = new MemoryStream();
                await stream.CopyToAsync(ms);
                ms.Seek(0, SeekOrigin.Begin);

                using var skBitmap = SKBitmap.Decode(ms.ToArray());
                if (skBitmap == null)
                    return Json(new { success = false, message = "Không đọc được ảnh." });

                var reader = new SKBitmapLuminanceSource(skBitmap);
                var binarizer = new ZXing.Common.HybridBinarizer(reader);
                var binaryBitmap = new ZXing.BinaryBitmap(binarizer);

                var result = new ZXing.MultiFormatReader().decode(binaryBitmap);

                if (result != null)
                    return Json(new { success = true, result = result.Text });
                else
                    return Json(new { success = false, message = "Không nhận diện được QR!" });
            }
            catch
            {
                return Json(new { success = false, message = "Lỗi xử lý ảnh." });
            }
        }
    }
}