﻿using Factory_Equipment_Management.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Factory_Equipment_Management.Controllers
{
    public class ItemDetailController : Controller
    {
        private readonly ItemDetailRepository itemDetailRepository;
        public ItemDetailController(ItemDetailRepository _itemDetailRepository)
        {
            itemDetailRepository = _itemDetailRepository;
        }

        [HttpGet("/ItemDetail/{id}")]
        public async Task<IActionResult> Index(int id)
        {
            var model = await itemDetailRepository.GetItemDetailAsync(id);
            if (model == null) return NotFound();
            return View("~/Views/ItemDetails.cshtml", model);
        }

       
    }
}
