﻿using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


[Authorize(Roles = "Admin,Manager,PIC")]
public class InforItemController : Controller
{
    private readonly InforItemRepository _repository;

    public InforItemController(InforItemRepository repository)
    {
        _repository = repository;
    }

    [HttpGet]
    public async Task<IActionResult> Index(
    int page = 1, int pageSize = 10,
    string name = null,
    float? maintanceCycle = null,
    float? duration = null,
    int? alertMaintance = null,
    int? alertRenew = null)
    {
        var (items, totalCount) = await _repository.GetPagedAsync(
            page, pageSize, name, maintanceCycle, duration, alertMaintance, alertRenew);

        // Lấy dữ liệu cho dropdown
        ViewBag.MaintanceCycles = await _repository.GetUniqueMaintanceCyclesAsync();
        ViewBag.Durations = await _repository.GetUniqueDurationsAsync();
        ViewBag.AlertMaintances = await _repository.GetUniqueAlertMaintancesAsync();
        ViewBag.AlertRenews = await _repository.GetUniqueAlertRenewsAsync();

        ViewBag.CurrentPage = page;
        ViewBag.PageSize = pageSize;
        ViewBag.TotalCount = totalCount;
        return View("~/Views/InforItem.cshtml", items);
    }

    [HttpPost]
    public async Task<IActionResult> Update(InforItemViewModel model)
    {
        if (model.IdCategory == 0)
            return BadRequest("IdCategory không được để trống.");

        var success = await _repository.UpdateItemAsync(model);
        if (success)
            return Ok(new { message = "Cập nhật thành công!" });
        else
            return BadRequest("Cập nhật thất bại!");
    }

    [HttpGet]
    public async Task<IActionResult> GetDeviceNames(string term)
    {
        var names = await _repository.GetDeviceNamesAsync(term);
        return Json(names);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllRealCategories()
    {
        var realCategories = await _repository.GetAllRealCategoriesAsync();
        return Json(realCategories);
    }

    [HttpPost]
    public async Task<IActionResult> Add(InforItemViewModel model)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(model.Name))
                return BadRequest(new { message = "Tên thiết bị không được để trống." });

            var success = await _repository.AddItemAsync(model);
            if (success)
                return Ok(new { message = "Thêm thiết bị thành công!" });
            else
                return BadRequest(new { message = "Thêm thiết bị thất bại!" });
        }
        catch (Exception ex)
        {
            // Trả về lỗi chi tiết cho client để dễ debug
            return StatusCode(500, new { message = ex.ToString() });
        }
    }

    //// Delete items
    //[HttpPost]
    //public async Task<IActionResult> Delete(int idCategory)
    //{
    //    try
    //    {
    //        var success = await _repository.DeleteCategoryAsync(idCategory);
    //        if (success)
    //            return Ok(new { message = "Xóa thành công!" });
    //        else
    //            return BadRequest("Không tìm thấy hoặc xóa thất bại!");
    //    }
    //    catch (Exception ex)
    //    {
    //        // Trả về lỗi chi tiết cho client (chỉ nên làm khi debug)
    //        return StatusCode(500, ex.ToString());
    //    }
    //}
}