﻿namespace Factory_Equipment_Management.ViewModel
{
    public class RegisterDeviceListItemViewModel
    {
        public int idRegisterDevice { get; set; }
        public string name { get; set; }
        public int num { get; set; }
        public string status { get; set; }
        public DateTime date { get; set; }
    }

    public class RegisterDeviceCreateViewModel
    {
        public string Name { get; set; } // Tên thiết bị
        public int Type { get; set; } // 1: cố định, 0: log
        public int Num { get; set; }
        public string PO { get; set; }
        public IFormFile Image { get; set; } // File ảnh
        public int? MaintainceCycle { get; set; }
        public int? RenewCycle { get; set; }
        public int? AlertMaintaince { get; set; }
        public int? AlertRenew { get; set; }
        public DateTime? DangKiemDate { get; set; }
        public int IdRealCategory { get; set; } // Loại thực tế
    }
}
