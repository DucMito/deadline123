﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Factory_Equipment_Management.ViewModel
{
    public class InforWarehouseAndAreaPageModel
    {
        public List<WarehouseViewModel> Warehouses { get; set; } = new();
        public List<SelectListItem> PICs { get; set; } = new();
        public List<SelectListItem> WarehousesForArea { get; set; } = new();
    }

    public class WarehouseViewModel
    {
        public int IdWarehouse { get; set; }
        public string Name { get; set; }
        public int IdPIC { get; set; }
        public string PICName { get; set; }
        public List<AreaViewModel> Areas { get; set; } = new();
    }

    public class AreaViewModel
    {
        public int IdArea { get; set; }
        public string Name { get; set; }
    }
}