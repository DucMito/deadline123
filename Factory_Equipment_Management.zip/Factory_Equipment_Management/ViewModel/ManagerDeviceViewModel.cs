﻿using Factory_Equipment_Management.Models;

namespace Factory_Equipment_Management.ViewModel
{
    public class ManagerDeviceViewModel
    {
        public string UserRole { get; set; }
        public IEnumerable<DeviceDisplayModel> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalItems { get; set; }
        public int TotalPages { get; set; }


        //filter
        public string FilterDeviceName { get; set; }
        public string FilterLocation { get; set; }
        //public DateTime? FilterActivedDate { get; set; }
        //public DateTime? FilterMaintanceDate { get; set; }
        //public DateTime? FilterRenewDate { get; set; }

        public string FilterModel { get; set; }
        public string FilterSerialNumber { get; set; }
        public string FilterSupplier { get; set; }
        public string FilterContractor { get; set; }
    }

    public class DeviceDisplayModel
    {
        public int? idItem { get; set; }
        public string ItemName { get; set; }

        public int idCategory { get; set; }
        public int? idArea { get; set; }
        public string Name { get; set; }
        public string CategoryName { get; set; }
        public string LocationName { get; set; }
        public string WarehouseName { get; set; }
        public string image { get; set; }
        public string status { get; set; }
        public DateTime? activedDate { get; set; }
        public DateTime? maintanceDate { get; set; }
        public DateTime? dangKiem { get; set; }
        public DateTime? renewDate { get; set; }
        public int? type { get; set; }

        // Các trường mới cho chức năng chuyển kho hoặc đặc thù khác
        public int? Quantity { get; set; }   // Số lượng muốn chuyển
        public bool IsSelected { get; set; }         // Đã chọn để chuyển hay chưa
        public string Note { get; set; }

        public string comment { get; set; }
        public string serialNumber { get; set; }
        public string contractor { get; set; }
        public string supplier { get; set; }


        // Thuộc tính từ bảng realCategory
        public int idRealCategory { get; set; }
        public string nameRealCategory { get; set; }


    }
}
