﻿using System.Collections.Generic;

namespace Factory_Equipment_Management.ViewModel
{
    public class ItemTransferRequestAreaViewModel
    {
        public List<string> Warehouses { get; set; } = new();
        public Dictionary<string, List<string>> WarehouseAreas { get; set; } = new();
        public string SelectedWarehouse { get; set; }
        public string SelectedArea { get; set; }

        public List<TransferDeviceModel> Devices { get; set; } = new();
        public List<string> Areas { get; set; } = new();
        public List<string> DeviceTypes { get; set; } = new();
        public string SelectedDeviceType { get; set; }
    }
}